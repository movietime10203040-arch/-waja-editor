# Waja Editor Android wrapper

This is an Android Studio project for a basic Waja Editor app shell.

## Important
The app currently opens the hosted Waja Editor site:
`https://movietime10203040-arch.github.io/-waja-editor/`

The site currently returns 404, so the app will also show that error until GitHub Pages is fixed. This project is source code, **not a compiled APK**.

## Build an APK
1. Open this folder in Android Studio.
2. Let Gradle sync and install Android SDK Platform 35 if prompted.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Android Studio will show the APK location when complete.

A GitHub Actions workflow can build a debug APK automatically after this project is added to a GitHub repository.
